/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ultimatarea;

/**
 *
 * @author pelaoo
 */
public class Ultimatarea {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
